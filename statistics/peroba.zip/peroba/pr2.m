clear all
close all
figure
hold on
x = poissrnd(3, 1, 100);

xx = min(x):0.01:max(x);
plot(xx, poisscdf(xx, 3), 'r.'); % thoretische Verteilungsf.

v=sort(x);
tt=min(x):0.01:max(x);
j=0;
Frep=zeros(1,length(tt));
for t=min(x):0.01:max(x)
j=j+1;
Frep(j)=sum(v<=t)/length(x); % empirische Verteilungsfunktion
end
plot(tt,Frep,'b.');

pe = sum(x > 3) / 100
%pt = 1 - poisscdf(3,3)

e = mean(x)

v = var(x)