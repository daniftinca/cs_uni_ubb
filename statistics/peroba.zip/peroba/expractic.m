x = binornd(15, 0.4, 1, 1000);
p = (sum(x < 10) - sum(x < 2)) / 1000 % empirisch P(2< x < 10)
pt = binocdf(10, 15, 0.4) - binocdf(2, 15, 0.4) % theoretisch P(2< x < 10)
e = mean(x) % empiriches Erwartungswert
ct = 0;
for i = 1:1000
  ct = ct + i * binopdf(i, 15, 0.4);
endfor
et = ct % theoretisches Erwartungswert
u = unique(x);
[nh,yh] = hist(x,u);
figure
hold on
bar(yh,nh/sum(nh)); % Hisogramm der relativen Haufigkeit ; sum(nh) = 1000