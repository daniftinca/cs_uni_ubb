x = binornd(100, 0.02, 1, 100);

p1 = sum(x < 3) / 100

p2 = sum(x > 10) / 100

p3 = (sum(x <= 15) - sum(x <= 5)) / 100

%p11 = binocdf(3, 100, 0.02)
%p22 = 1 - binocdf(10, 100, 0.02)
%p33 = binocdf(15, 100, 0.02) - binocdf(5, 100, 0.02)