% 1
% a) n = 100; p = 0.05; N = 200;
X = binornd(100, 0.05, 1, 200);
% b) 
mitanz = mean(X)
% c) 1)
p3 = binocdf(3, 100, 0.05)
% c) 2)
p10 = binopdf(10, 100, 0.05)
% c) 3)
p4 = 1 - binocdf(3, 100, 0.05)

% 2
x = normrnd(10000, 1000, 1, 10)
p1 = 1 - normcdf(12000, 10000, 1000)
p2 = 1 - normcdf(6500, 10000, 1000)
p3 = normcdf(10500, 10000, 1000) - normcdf(7500, 10000, 1000)
gladiola = norminv(0.05, 10000, 1000)

% 3
X = [301 , 329 , 309 , 331 , 328 , 325, 327 ,333 , 314 , 305, 302, 315];
n = 12;
durchlebensdauer = mean(X)
estd = std(X)
h=ttest(X,315,'alpha',0.05,'Tail','left')
t = (mean(X) - 315) / (std(X) / sqrt(n))
q = tinv(0.05, n-1)
if t > q
  disp('man aktzeptiert H0')
else
  disp('man lehnt H0 ab')
endif

% 4
x =[299, 299 , 297, 300 , 299, 301, 300, 297, 302, 303, 300, 299, 301, 302, 301, 299, 300, 298, 300, 300, 296, 304,295,295,297];
% Histogram abs. Haufigkeit
u = unique(x);
figure
hold on
hist(x,u);

% Histogram rel. Haufigkeit
[nh, yh] = hist(x,u);
figure
hold on
bar(yh, nh/ sum(yh));

% 5
% a < 9
p1 = normcdf(9, 10, 1)
% 8.9 <= <= 10.1
p2 = normcdf(10.1, 10, 1) - normcdf(8.9, 10, 1)
% > 15 
p3 = normcdf(5, 10, 1) + (1 - normcdf(15, 10, 1))
% b 
x = normrnd(10, 1, 1, 1000);
p11 = sum(x < 9) / 10000
p12 = (sum(x < 10.1) - sum(x < 8.9)) / 10000
p13 = (sum(x < 5) + sum(x > 15)) / 10000


% 6
figure
hold on
x = poissrnd(1, 1, 1000);
xx = min(x):0.01:max(x);
plot(xx, poisscdf(xx,1), 'r.'); % theoretische Verteilungsfunktion

p1 = sum(x > 1) / 1000
p1 = 1 - poisscdf(1,1)
e = mean(x) % erwartungswert cremshnitt e = sum(x) / 1000
v = var(x) % varianz

v=sort(x);
tt=min(x):0.01:max(x);
j=0;
Frep=zeros(1,length(tt));
for t=min(x):0.01:max(x)
j=j+1;
Frep(j)=sum(v<=t)/length(x); % empirische Verteilungsfunktion
end
plot(tt,Frep,'b.');

% 7
% A(0, 0), B(0, 1), C(0, 2), D(1, 2), E(2, 2), F(2, 1), G(2, 0), H(1, 0)
xa = 0; ya = 0;
xb = 0; yb = 1;
xc = 0; yc = 2;
xd = 1; yd = 2;
xe = 2; ye = 2;
xf = 2; yf = 1;
xg = 2; yg = 0;
xh = 1; yh = 0;

ct = 0;
n = 1000;
for i = 1:n
  xm = rand() * 2;
  ym = rand() * 2;
  % ABH => M, A auf derselben Seite von BH
  ok1 = (((ym - yh) / (yb - yh)) - ((xm - xh) / (xb - xh))) * (((ya - yh) / (yb - yh)) - ((xa - xh) / (xb - xh))) > 0;
  % BCD => M, C auf derselben Seite von BD
  ok2 = (((ym - yd) / (yb - yd)) - ((xm - xd) / (xb - xd))) * (((yc - yd) / (yb - yd)) - ((xc - xd) / (xb - xd))) > 0;
  % DEF => M, E auf derselben Seite von DF
  ok3 = (((ym - yf) / (yd - yf)) - ((xm - xf) / (xd - xf))) * (((ye - yf) / (yd - yf)) - ((xe - xf) / (xd - xf))) > 0;
  % FGH => M, G auf derselben Seite von FH
  ok4 = (((ym - yh) / (yf - yh)) - ((xm - xh) / (xf - xh))) * (((yg - yh) / (yf - yh)) - ((xg - xh) / (xf - xh))) > 0;
  if(ok1 == 1 && ok2 == 1 && ok3 == 1 && ok4 == 1)
    ct = ct + 1;
  endif
endfor

p7 = (n - ct) / n

M = 1000

ct=0;
for i=1:M
  x=rand()*2;
  y=rand()*2;
  if(y<=x+1 && y>=x-1 && y<=-x+3 && y>=-x+1)
    ct += 1;
    endif
endfor
pp7 = ct / M
Fl = 4*ct/M

% 8
M=3000

size=0;
ct=0;  
for x=1:0.0001:2
    y=rand()*M;
    if(y<=exp(2*x*x))
      ct+=1;
    endif
    size+=1;
endfor

ct
size
integral = ((2-1)*M)*(ct/size)

% 9
n = 100;
ct = 0;
for i = 1:n
  summe = 0;
  x = normrnd(0, 1, 1, 500);
  summe = sum(x);
  if(summe >= -20 && summe <= 10)
    ct = ct + 1;
  endif
endfor
p9 = ct / n

% 10
x = normrnd(3, 1, 1, 1000); % sqrt(Varianz) = Sigma sqrt(1) = 1 aici
p10a = (sum(x > 4) + sum(x < -4)) / 1000
p10b = (1 - normcdf(4, 3, 1)) + normcdf(-4, 3, 1)

% 11 6 rote, 4 wei�e und 5 blaue -> rot, weis, blau
n = 100;
% a) zuruckgelegt
pr = 6/15;
pw = 4/15;
pb = 5/15;
ct = 0;
for i = 1:n
  r = floor(rand() + pr);
  w = floor(rand() + pw);
  b = floor(rand() + pb);
  if(r == 1 && w == 1 && b == 1)
    ct = ct + 1;
  endif
endfor
p11a = ct / n
% b) nicht zuruckgelegt
pr = 6/15;
pw = 4/14;
pb = 5/13;
ct = 0;
for i = 1:n
  r = floor(rand() + pr);
  w = floor(rand() + pw);
  b = floor(rand() + pb);
  if(r == 1 && w == 1 && b == 1)
    ct = ct + 1;
  endif
endfor
p11b = ct / n

% 12
p1 = 4/6;
p2 = 2/6;
% a)
% b)
n = 1000;
ct2 = 0;
ct3 = 0;
ct4 = 0;
ct = 0;
for i = 1:n
  x = floor(rand(1,2) + p1); % 1 => 1, 0 => 2
  summe = sum(x) + 2 * (2 - sum(x));
  ct = ct + summe;
  if(summe == 2)
    ct2 = ct2 + 1;
  endif
  if(summe == 3)
    ct3 = ct3 + 1;
  endif
  if(summe == 4)
    ct4 = ct4 + 1;
  endif 
endfor
p2 = ct2 / n
p3 = ct3 / n
p4 = ct4 / n
groser2 = p3 + p4
e = ct / 1000