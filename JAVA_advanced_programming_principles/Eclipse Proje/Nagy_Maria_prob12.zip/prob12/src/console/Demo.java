package console;

import java.util.Arrays;
import java.util.Scanner;

import algorithms.ExOne;
import algorithms.ExTwo;

public class Demo {

	public Demo() {

	}

	public static void main(String args[]) {

		while (true) {
			Scanner keyboard = new Scanner(System.in);
			System.out.println("Enter the number of the problem (1 or 2): ");
			int myInt = keyboard.nextInt();
			if (myInt == 1) {
				int matrixSize = 4;

				ExOne obj = new ExOne(matrixSize);

				obj.fillMatrixRandom(16);
				System.out.println("Initial Matrix:\n");
				obj.printMatrix();
				System.out.println("\n");
				obj.rotateMatrixClockwise();
				System.out.println("Result Matrix:\n");
				obj.printMatrix();
				System.out.println("\n");
			} else {

				ExTwo arrayObj = new ExTwo();
				int[] array1 = { 1, 3, 4, 5, 9 };
				System.out.println("Original array: " + Arrays.toString(array1));

				int nrOfShifts = 2;
				arrayObj.setSortedArray(array1);
				arrayObj.shiftArray(nrOfShifts);

				int[] shiftedArray = arrayObj.getSortedArray();
				System.out.println(
						"Array shifted " + nrOfShifts + " times to the right: " + Arrays.toString(shiftedArray));
				System.out.println("Enter the target number: ");
				int myInt2 = keyboard.nextInt();
				int getIndex = arrayObj.getShiftedArrayNrIndex(myInt2, 0, 4);
				System.out.println("The index of the target number is: " + getIndex + "\n");
			}
		}
	}

}
