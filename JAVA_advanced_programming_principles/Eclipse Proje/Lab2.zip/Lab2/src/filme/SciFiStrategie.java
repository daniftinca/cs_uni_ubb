/**
 * 
 */
package filme;

/**
 * @author Dan
 *
 */
public class SciFiStrategie implements DefaultPreisStrategie {
	
	@Override
	public double kalkulierePreis(double preis) {
		return preis*0.9;
	}
}
