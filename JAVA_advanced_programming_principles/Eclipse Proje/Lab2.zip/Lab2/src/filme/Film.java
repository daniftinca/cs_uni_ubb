/**
 * 
 */
package filme;

/**
 * @author Dan Klasse die einen Film repraesentiert.
 */
public class Film {

	private String titel;
	private int erschienJahr, bewertung;
	private float basisPreis;
	private String[] listeSchauspieler;

	private DefaultPreisStrategie strat;

	public Film(String titel, int erschienJahr, int bewertung, float basisPreis, String[] listeSchauspieler,
			DefaultPreisStrategie strat) {
		super();
		this.titel = titel;
		this.erschienJahr = erschienJahr;
		this.bewertung = bewertung;
		this.basisPreis = basisPreis;
		this.listeSchauspieler = listeSchauspieler;
		this.strat = strat;
	}

	/**
	 * Die Method berechnet den finalen Preis eines Films, indem sie die
	 * Preisstrategie der Objekt benutzt.
	 * 
	 * @return double - finalen preis
	 */
	public double kalkulierePreis() {
		return strat.kalkulierePreis(basisPreis);
	}

	public String getTitel() {
		return titel;
	}

	public void setTitel(String titel) {
		this.titel = titel;
	}

	public int getErschienJahr() {
		return erschienJahr;
	}

	public void setErschien_jahr(int erschienJahr) {
		this.erschienJahr = erschienJahr;
	}

	public int getBewertung() {
		return bewertung;
	}

	public void setBewertung(int bewertung) {
		this.bewertung = bewertung;
	}

	public float getBasispreis() {
		return basisPreis;
	}

	public void setBasisPreis(float basisPreis) {
		this.basisPreis = basisPreis;
	}

	public String[] getListeSchauspieler() {
		return listeSchauspieler;
	}

	public void setListeSchauspieler(String[] listeSchauspieler) {
		this.listeSchauspieler = listeSchauspieler;
	}

}
