/**
 * 
 */
package filme;

/**
 * @author Dan
 *
 */
public class HorrorStrategie implements DefaultPreisStrategie {

	@Override
	public double kalkulierePreis(double preis) {
		return preis * 0.5;
	}
}
