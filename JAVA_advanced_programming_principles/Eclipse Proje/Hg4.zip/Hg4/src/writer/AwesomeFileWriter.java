/**
 * 
 */
package writer;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import exceptions.FileWriterException;
import filme.Film;

/**
 * @author Dan
 * Class that specializes in writing to normal files.
 */
public class AwesomeFileWriter implements AwesomeWriter {

	/* (non-Javadoc)
	 * @see writer.AwesomeWriter#writeMovies(java.util.ArrayList)
	 */
	@Override
	public void writeMovies(ArrayList<Film> paramList, String fileName) throws FileWriterException {
		    PrintWriter writer = null;
		    String actorNames = "";
			try {
				writer = new PrintWriter(fileName, "UTF-8");
		
		    for(int i=0;i<paramList.size();i++) {
		    
		    Film film=paramList.get(i);
		    
		    writer.println(film.getTitel());   
		    writer.println(film.getErschienJahr());    
		    writer.println(film.getBewertung());
		    String[] actorList = film.getListeSchauspieler();
		    for(int j=0;j<actorList.length;j++) {
		     
		    	actorNames += actorList[j]+", ";
		    }
			    writer.println(actorNames);  
			    writer.println(film.getBasispreis());
			    actorNames="";
			}
		    writer.close();
			} catch (FileNotFoundException e) {
				throw new FileWriterException("FileWriterException: File not found");
			} catch (UnsupportedEncodingException e) {
				throw new FileWriterException("FileWriterException: Unsupported Encoding");
			}
		   
	}

}
