package exceptions;
/**
 * Class that handles all Writer Exceptions.
 * @author Dan
 *
 */
public class WriterException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6315139296161791548L;

	public WriterException() {
		// TODO Auto-generated constructor stub
	}

	public WriterException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public WriterException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public WriterException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public WriterException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
