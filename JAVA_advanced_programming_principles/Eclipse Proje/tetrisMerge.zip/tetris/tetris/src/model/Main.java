package model;

import java.util.ArrayList;
import java.util.List;

import aiPart.Brain;

public class Main {

	public static void main(String[] args) {
		List<Integer> lista = new ArrayList<>();
		lista.add(1);
		lista.add(2);
		lista.add(3);
		
		
		Brain brain = new Brain(5, lista);
		
		//Nod castig = brain.dfsUsingStack();
		Nod castig2 = brain.gbfs();
		System.out.println(castig2);
		
	}

}
