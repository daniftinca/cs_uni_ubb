package exceptions;

public class MyException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3498902324645097081L;

	public MyException(String message) {
		super(message);
	}
}
