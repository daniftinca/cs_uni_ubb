bus24(campus_universitar).
bus24(arte_plastice).
bus24(crinului).
bus24(somes).
bus24(regionala_cfr).
bus24(sora).
bus24(memorandumului).
bus24(spitalul_de_copii).
