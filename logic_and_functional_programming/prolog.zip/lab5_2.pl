lange([], 0).
lange([X|Y],Ct) :- write(X),lange(Y,Ct2), Ct is Ct2 + 1.


anz([], _, 0).
anz([E|X], E, Ct) :- anz(X, E, Ct1), Ct is Ct1 + 1.
anz([X|Y], E, Ct) :- anz(Y, E, Ct).

groessest([], 0).
groessest([X], X).
groessest([X|Y], X) :- X>Z, groessest(Y, Z).
