bus24(campus_universitar).
bus24(arte_plastice).
bus24(crinului).
bus24(somes).
bus24(regionala_cfr).
bus24(sora).
bus24(memorandumului).
bus24(spitalul_de_copii).
bus25(sora).
bus25(memorandumului).
bus25(spitalul_de_copii).
gemeinsam(X) :- bus24(X), bus25(X).
