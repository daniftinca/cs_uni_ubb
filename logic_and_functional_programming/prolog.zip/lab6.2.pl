zug(1).
zug(2).
zug(3).
zug(_).
con(L1, L2, L3):-(L1=[], L2=L3); (L3=[X|R],L1=[X|Y],con(Y,L2,R)).
%bahnhof([zug(3)], [frei, zug(1), frei, zug(2)]).
einfugen([],V,N):-V=N.
einfugen(Z,[V|X],[Z|X]):-V=frei.
einfugen(Z,[X|Y],L):-einfugen(Z,Y,U),L=[X|U].

istFrei([]):-false.
istFrei([X|Y]):-X=frei;istFrei(Y).
bewegen(bahnhof([], G), bahnhof([], G)).
bewegen(bahnhof(W, G), bahnhof(W, G)):-not(istFrei(G)).
bewegen(bahnhof([Z|W], G), bahnhof(WNeu, GNeu)):-
einfugen(Z,G,G2),bewegen(bahnhof(W,G2), bahnhof(WNeu,GNeu)).
neuerZug(Z, bahnhof(W, G), bahnhof(WNeu, GNeu)):-
bewegen(bahnhof(W,G), bahnhof(W2,GNeu)), con(W2, [Z], WNeu).
