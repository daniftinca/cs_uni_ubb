pers(ioan).
pers(dan).
pers(andrei).
pers(ana).
pers(diandru).
pers(stefi).
pers(cristi).
pers(cosmin).
rang(ioan, intern).
rang(dan, senior).
rang(andrei, junior).
rang(ana, junior).
rang(diandru, senior).
rang(stefi, intern).
rang(cristi, junior).
rang(cosmin, senior).
bossvon(diandru, andrei).
bossvon(andrei, ioan).
bossvon(dan, stefi).
bossvon(andrei, cristi).
bossvon(cosmin, dan).
bossvon(cosmin, diandru).
superior(X, Y) :- bossvon(X,Y).
superior(X, Y) :- bossvon(X, Z), superior(Z,Y).
gleichrang(X, X).
gleichrang(X, Y) :- bossvon(B1, X), bossvon(B2, Y), gleichrang(B1, B2).
