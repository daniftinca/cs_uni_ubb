add(X,0,X). % x + 0 = x
add(X,s(Y),s(Z)) :- add(X,Y,Z).
mul(X,0,0).
mul(X,s(0),X).
mul(X,s(Y),W) :- mul(X,Y,Z), add(X,Z,W).
% x * (y+1) = w daca x * y = z unde x + z = w
fact(0,s(0)).
fact(s(0),s(0)).
fact(s(X),Z) :- fact(X,Y), mul(s(X),Y,Z).
