add(0,X,X).
add(X,Y,Z):-X1 is X-1,add(X1,Y,Z1), Z is Z1+1.
%add(X,Y,Z):-Y1 is Y-1, add(X,Y1,Z1), Z is Z1+1.
mul(1,X,X).
mul(X,Y,Z):-X1 is X-1, mul(X1,Y,R), add(Y,R,Z).
mod(X,X,0).
mod(Y,X,0):-Y>X,Z is Y-X,mod(Z,X,0).
mod(Y,X,Z):-Z>0, R is Y-Z, mod(R,X,0).
sum(X,Y,Z):-integer(X),integer(Y),integer(Z),Z is X+Y.
