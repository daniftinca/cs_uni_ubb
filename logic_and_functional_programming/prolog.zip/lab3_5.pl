a.
c.
e.
und(X,Y) :- X,Y.
oder(X,Y) :- X;Y.
noder(X,Y) :- oder(X,Y), not(und(X,Y)).
impl(X,Y) :- oder(not(X),Y).
equ(X,Y) :- impl(X,Y), impl(Y,X).
tafel(A,B,C) :- impl(und(A,B),C).
