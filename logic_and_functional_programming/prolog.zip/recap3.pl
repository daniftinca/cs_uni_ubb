isPrime(2).
isPrime(3).
isPrime(X):-X>3,
