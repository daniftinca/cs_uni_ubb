maennlich(paul). % Paul ist m�annlich
maennlich(fritz). % Fritz ist m�annlich
maennlich(steffen).% Steffen ist m�annlich
weiblich(karin). % Karin ist weiblich
weiblich(lisa). % Lisa ist weiblich
weiblich(maria). % Maria ist weiblich
weiblich(sina). % Sina ist weiblich
vater(steffen, paul). % Steffen ist der Vater von Paul
vater(fritz, karin). % Fritz ist der Vater von Karin
vater(steffen, lisa). % Steffen ist der Vater von Lisa
vater(paul, maria). % Paul ist der Vater von Maria
mutter(karin, maria). % Karin ist die Mutter von Maria
mutter(sina, paul). % Sina ist die Mutter von Paul
paar(M,F) :- maennlich(M), weiblich(F), vater(M,X), mutter(F,X).
geschwister(X,Y) :- mutter(M,X), mutter(M,Y), vater(V,X), vater(V,Y).
nefe(N,X) :- (geschwister(X,Y), mutter(Y,N)); (geschwister(X,Z),vater(Z,N)).
