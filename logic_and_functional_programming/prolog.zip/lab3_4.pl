%add(0,X,X).
%add(X,Y,Z):- X1 is X-1, add(X1,Y,Z1), Z is Z1+1.
add(0,Y,Y).
add(s(X),Y,s(Z)):-add(X,Y,Z).
kleiner_gleich(X,Y) :- add(W,X,Y).
kleiner(X,Y) :- kleiner_gleich(s(X),Y).

