special(X) :- X*X > 999, X*X < 10000, X*X mod 100 + X*X//100 =:= X.
