:-op(500, fx, not).
not(X) :- \+X.
:-op(600, xfy, und).
und(X,Y) :- X,Y.
:-op(700, xfy, oder).
oder(X,Y) :- X;Y.

formel(A) :- member(A,[a,b,c,d]).
formel(A und B) :- formel(A), formel(B).
formel(not A) :- formel(A).
formel(A oder B) :- formel(A), formel(B).

formel_anz(0, A) :- member(A,[a,b,c,d]).

formel_anz(Ct,A und B) :- formel_anz(Ct1, A), formel_anz(Ct2, B), Ct is Ct1 + Ct2.
formel_anz(Ct,A oder B):- formel_anz(Ct1, A), formel_anz(Ct2, B), Ct is Ct1 + Ct2.
formel_anz(Ct,not A) :- formel_anz(Ct1, A), Ct is Ct1+1.

anz_buchstaben(1,A) :- member(A,[a,b,c,d]).

anz_buchstaben(Ct,A und B) :- anz_buchstaben(Ct1, A), anz_buchstaben(Ct2, B),
Ct is Ct1+Ct2.
anz_buchstaben(Ct,A oder B) :- anz_buchstaben(Ct1, A), anz_buchstaben(Ct2, B),
Ct is Ct1+Ct2.
anz_buchstaben(Ct, not A) :- anz_buchstaben(Ct, A).
