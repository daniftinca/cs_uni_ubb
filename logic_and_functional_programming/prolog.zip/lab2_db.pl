vertreter(8413,meyer,bremen,0.07,725.15).
vertreter(5016,meier,hamburg,0.05,200.00).
vertreter(1215,schulze,bremen,0.06,50.50).
artikel(12,oberhemd,39.80).
artikel(22,mantel,360.00).
artikel(11,oberhemd,44.20).
artikel(13,hose,110.5).
umsatzdaten(8413,12,40,24).
umsatzdaten(5016,22,10,24).
umsatzdaten(8413,11,70,24).
umsatzdaten(1215,11,20,25).
umsatzdaten(5016,22,35,25).
umsatzdaten(8413,13,35,24).
umsatzdaten(1215,13,5,24).
umsatzdaten(1215,12,10,24).
umsatzdaten(8413,11,20,25).
tatigkeit(X, Y, Z) :-  vertreter(Id, X, V1, V2, V3), artikel(Id2, Y, V4), umsatzdaten(Id, Id2, V5, Z).











