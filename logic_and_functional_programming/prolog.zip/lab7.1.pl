zweites(X, [_|L]):- L = [X|_].
drittes(X, [_|L]):- L = [_|P], P = [X|_].
letztes(X, L):- L=[X];(letztes(X,Z), L=[_|Z]).

concat2([X], L, [X|L]).
concat2([X|R],Y,[X|Z]):-concat2(R,Y,Z).


verkette([L], L).
notempty([]).
notempty([X|R]):-X=[_|_],notempty(R).
verkette([X|R], L):-X=[_|_],notempty(R),R=[Y|R2], concat2(X,Y,Z), L2=[Z|R2], verkette(L2, L).

