last(E,[E]).
last(E,[_|R]):-last(E,R).
concat([],L,L).
concat([X|R],L,[X|Z]):-concat(R,L,Z).
palindrom([]).
palindrom([_]).
palindrom([X|R]):-last(E,[X|R]),X=E,concat(Z,[E],R),palindrom(Z).
