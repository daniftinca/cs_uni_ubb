% is prime(P) :- P ist prim
% (integer) (+)
isprime(2).
isprime(3).
isprime(P) :- integer(P), P > 3, P mod 2 =\= 0, notfactor(P,3).
% has factor(N,L) :- N has an odd factor F >= L.
% (integer, integer) (+,+)
hasfactor(N,L) :- N mod L =:= 0.
hasfactor(N,L) :- L * L < N, L2 is L + 1, hasfactor(N,L2).
notfactor(N,L) :- L * L > N.
notfactor(N,L) :- N mod L =\= 0, notfactor(N,L+2).














