eq(X,X).
for(0).
for(s(Y)) :- for(Y).

