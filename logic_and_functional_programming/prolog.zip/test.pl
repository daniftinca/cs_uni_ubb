john.
mary.
eats(john).
likes(mary,john).
likes(X,Y) :- likes(Y,X).
