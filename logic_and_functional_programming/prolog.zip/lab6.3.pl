verbindung([a,b,d],a).
verbindung([f,g],a).
verbindung([c,d,e],t).
verbindung([c,e,f],t).
verbindung([a,b,c],k).
inListe([V|R],X):-V=X;inListe(R,X).
weiterHinten(L,A,B):-(L=[A|R], member(B,R));
(L=[_|R],weiterHinten(R,A,B)).
moglich(A,B,[X|Y]):-(member(E,[X|Y]),verbindung(L,E), weiterHinten(L,A,B));
(member(E,[X|Y]), verbindung(L,E), weiterHinten(L,A,C),moglich(C,B,[X|Y])).
