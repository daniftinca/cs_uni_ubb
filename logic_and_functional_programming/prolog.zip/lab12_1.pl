l1([true,false,true]).
l2([true,true,false]).
