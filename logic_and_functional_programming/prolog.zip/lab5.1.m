:-op(500,xfy,und).
und(X,Y,X&Y).
