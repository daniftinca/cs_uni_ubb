%G5

vertreter(8413,meyer,bremen,0.07,725.15).
vertreter(5016,meier,hamburg,0.05,200.00).
vertreter(1215,schulze,bremen,0.06,50.50).

artikelstammdaten(12,oberhemd,39.80).
artikelstammdaten(22,mantek,360.00).
artikelstammdaten(11,oberhemd,44.20).
artikelstammdaten(13,hose,110.5).

umsatzdaten(8413,12,40,24).
umsatzdaten(5016,22,10,24).
umsatzdaten(8413,11,70,24).
umsatzdaten(1215,11,20,25).
umsatzdaten(5016,22,35,25).
umsatzdaten(8413,13,35,24).
umsatzdaten(1215,13,5,24).
umsatzdaten(1215,12,10,24).
umsatzdaten(8413,11,20,25).

%a) care articol de imbracaminte are un anumit numar
whicharticle(Article,Nr):-artikelstammdaten(Nr, Article, Price).

%b) daca Vertreter-ul cu nr X are Umsatz in data de Y
hatumsatz(Nr,Day):-umsatzdaten(Nr,_,_,Day).

% vedem daca un Vertreter a cumparat (relocat de fapt) un produs cu un
% anumit numar
verbuysprodname(Nr,Day,Name,NrP):-vertreter(Nr,Name,_,_,_),umsatzdaten(Nr,NrP,_,Day).

%c) daca Vertreter-ul cu nr X, a cumparat in data Y produsul Z
%vedem daca Vertreter cu nr X a cumparat in ziua Y produsul cu nr Z
verbuysprod(Nr,Day,NrP):-umsatzdaten(Nr,NrP,_,Day).

productbought(NrP,DayP,Product):-artikelstammdaten(NrP,Product,_),umsatzdaten(_,NrP,_,DayP).

hasbought(Nr,Day,Product):-verbuysprod(Nr,Day,NrP),productbought(NrP,Day,Product).

% d)
gibtumsatzart(Art1,Art2,Day):-umsatzdaten(_,Art1,_,Day);umsatzdaten(_,Art2,_,Day).

%G7
% daca un Vertreter cu numele X a cumparat produsul Y in ziua Z
% hasboughtt ne da si numele celui care a cumparat produsele; Nrp e acum
% legat de Nrp din productbought, deci trebuie sa coincida
hasboughtt(Nr,Name,Day,Product):-verbuysprodname(Nr,Day,Name,NrP),productbought(NrP,Day,Product).

tatigkeit(Name,Product,Day):-hasboughtt(Nr,Name,Day,Product).
