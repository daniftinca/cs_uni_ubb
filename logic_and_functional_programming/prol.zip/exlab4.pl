%G17
%laengee(L,N):-length(L,N).
%a) Gesucht ist ein Pradikat laenge(L, N), welches die Lange N einer Liste L berechnet.

laenge([],0).
laenge([_|T],N+1):-laenge(T,N). %laenge([1,2,3],X). => X=0+1+1+1


lae([],0).
lae([_|T],N):-lae(T,Z),N is Z+1. %sau laenge(T,Z),N is Z+1. => X=3

%b) Gesucht ist ein Pradikat zaehle(L, E, N), welches die Anzahl N der Vorkommen des
%Elementes E in einer Liste L bestimmt.

zaehle([],_,0).
zaehle([E|Tail],E,N):-zaehle(Tail,E,Z), N is 1+Z.
zaehle([E1|Tail],E,Z):-E1\=E,zaehle(Tail,E,Z).

%c) Gesucht ist ein Pradikat gleichlang(L1, L2),
% das genau dann erfullt ist, wenn L1 und L2 Listen gleicher Lange
% sind.

gleichung(L1,L2):-lae(L1,N),lae(L2,N).


