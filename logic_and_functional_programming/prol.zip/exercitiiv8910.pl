dic(ha,ko).
dic(ha,fu).
dic(ko,ka).
dic(ko,ma).
dic(fu,mu).
dic(ma,fr).

ic(Von,Nach):-dic(Von,Nach).
ic(Von,Nach):-dic(Von,Z),ic(Z,Nach).

%ic(Von,Nach):-dic(Von,Z),write('mogliche Zwischenstation: '),
%    write(Z),nl,ic(Z,Nach). %scrie statiile posibile dintre Von si Nach


anfrage:-write('Gib Abfahrtsort: '),nl,read(Von), %read citeste de la tastatura
    write('Gib Ankunfsort: '),nl,read(Nach),    %write e print
    ic(Von,Nach), %daca e fals trece la urmatorul anfrage
    write('IC-Verbindung existiert').

anfrage:-write('IC-Verbindung existiert nicht').

%neben den m�oglichen Zwischenstationen
%zus�atzlich die Nummern der unifizierten Fakten (von 1 bis
%6) sowie die Nummern der unifizierten Regelk�opfe (1 oder
%2) anzeigen lassen
dicc(1,ha,ko).
dicc(2,ha,fu).
dicc(3,ko,ka).
dicc(4,ko,ma).
dicc(5,fu,mu).
dicc(6,ma,fr).

icc(1,Von,Nach):-write('Regel: 1'),nl,
    dicc(Nr,Von,Nach),
    write('Fakt: '),write(Nr),nl.
icc(2,Von,Nach):-write('Regel: 2'),nl,
    dicc(Nr,Von,Z),
    write('Fakt: '),write(Nr),nl,
    write('mogliche Zwischenstation: '),write(Z),nl,
    icc(_,Z,Nach). % am _ ca sa nu fie neaparat egala cu Nr din dicc

anfragee:-write('Gib Abfahrtsort: '),nl,read(Von), %read citeste de la tastatura
    write('Gib Ankunfsort: '),nl,read(Nach),    %write e print
    icc(_,Von,Nach), %daca e fals trece la urmatorul anfrage
    write('IC-Verbindung existiert').

anfragee:-write('IC-Verbindung existiert nicht').

anfrage1:-write('von: '),nl,
    read(Von),
    write('mogliche nach: '),nl,
    ic(Von,Nach),
    write(Nach),nl.

anfrage1:-nl,write('Ende').

anfrage2:-write( 'mogliche IC-Verbindung(en):'
),nl,
ic(Von,Nach),
write('Abfahrtsort:'),write(Von),nl,
write('Ankunftsort:'),write(Nach),nl.

b.
c.
e1.
e2.
e:-e1.
e:-e2.
f:-fail.
a:-b,!,c.
a:-b. %am verificat ca b e true, si atunci ca sa optimizam programul facem cut => nu il mai verifica pe a:-b.











