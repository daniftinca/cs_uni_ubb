function [result] = expLam(n, lam)
  u = rand(1,n);
  result = -log(u)/lam;
