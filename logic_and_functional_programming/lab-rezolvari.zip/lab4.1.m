close all
figure
rectangle('Position',[0,0,4,4],'Curvature',[0,0],'Facecolor',[0,0,0])
n = 1000
hold on
exact3=0;
all3=0;
stumpf=0;
for i=1:n
  m = [rand()*4, rand()*4];
  plot(m(1), m(2), 'y*')
  %text(m(1), m(2)-1, 'M')
  ct = 1;
  for x=0:4:4
    for y=0:4:4
      dist = sqrt((x-m(1))^2 + (y-m(2))^2);
      v(ct) = dist;
      ct++;
    endfor
   endfor
   if((v(1) > 3 && v(2) < 3 && v(3) < 3 && v(4) < 3) ||
      (v(1) < 3 && v(2) > 3 && v(3) < 3 && v(4) < 3) ||
      (v(1) < 3 && v(2) < 3 && v(3) > 3 && v(4) < 3) ||
      (v(1) < 3 && v(2) < 3 && v(3) < 3 && v(4) > 3))
      plot(m(1), m(2), 'r*');
      exact3++;
   endif
   
    if(v(1) < 3 && v(2) < 3 &&
      v(3) < 3 && v(4) < 3)
      plot(m(1), m(2), 'b*');
      all3++;
    endif
    
    if(v(1)^2 + v(2)^2 < 16 && v(2)^2 + v(4)^2 > 16 &&
       v(3)^2 + v(4)^2 > 16 && v(1)^2 + v(3)^2 > 16)
       plot(m(1), m(2), 'g*');
       stumpf++;
    endif
    
    if(v(1)^2 + v(2)^2 > 16 && v(2)^2 + v(4)^2 < 16 &&
       v(3)^2 + v(4)^2 > 16 && v(1)^2 + v(3)^2 > 16)
       plot(m(1), m(2), 'g*');
       stumpf++;
    endif
    
    if(v(1)^2 + v(2)^2 > 16 && v(2)^2 + v(4)^2 > 16 &&
       v(3)^2 + v(4)^2 < 16 && v(1)^2 + v(3)^2 > 16)
       plot(m(1), m(2), 'g*');
       stumpf++;
    endif
    
    if(v(1)^2 + v(2)^2 > 16 && v(2)^2 + v(4)^2 > 16 &&
       v(3)^2 + v(4)^2 > 16 && v(1)^2 + v(3)^2 < 16)
       plot(m(1), m(2), 'g*');
       stumpf++;
    endif
      
endfor

disp("Wkt exakt 3:");
exact3/n
disp("Wkt kleiner als 3");
all3/n
disp("Wkt stumpfwinklig");
stumpf/n