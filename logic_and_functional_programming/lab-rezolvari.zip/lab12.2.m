 m0 = 1000;
 n = 64;
 sn = 25.6
 exn = 994;
 t = (exn - m0)/(sn/sqrt(n))
 ta = tinv(0.05, n-1)
 
 if(t > ta)
  disp('H0')
 else
  disp('H1')
 endif
 
 