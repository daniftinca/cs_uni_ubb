n = 10;
close all
figure
hold on
for i=1:n
    rectangle('Position',[rand(),rand(),rand(),rand()],'Curvature',[0,0],'Facecolor',[rand(), rand(), rand()]);
    end