function result  = mygeornd(p)
  i = floor(rand()+p);
  ct = 0;
  while(i != 1)
    i = floor(rand()+p);
    ct+=1;
  endwhile
  result = ct;
  return
endfunction  

function result = mybinon(r,p)
  i = floor(rand()+p);
  ct = 0;
  ctr = 0;
  while(ctr != r)
    if(i == 0)
      ct+= 1;
    else
      ctr+= 1;
    endif
    i = floor(rand()+p);
  endwhile
  result = ct;
  return
endfunction  

x=[]
p1=0.8;
p2=0.75;
p= p1+ p2 -p1*p2
for i=1:1000
  x(i)=mygeornd(p);
endfor

tabulate(x+1);

p=0.7
r=2;
x=[]  
for i=1:1000
  x(i)=mybinon(r,p);
endfor

tabulate(x+1);


