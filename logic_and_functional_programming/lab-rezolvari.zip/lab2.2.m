a=[randi(100), randi(100)]
b=[randi(100), randi(100)]
c=[randi(100), randi(100)]
d=[randi(100), randi(100)]

close all
figure
hold on 

m = (d(2)-c(2))/(d(1)-c(1))
n = - m*c(1) + c(2)

for i=1:100
  plot(i,i*m + n,'r*')
endfor
plot(a(1), a(2), 'b*')
text(a(1), a(2)-1, 'A')
plot(b(1), b(2), 'b*')
text(b(1), b(2)-1, 'B')
plot(c(1), c(2), 'b*')
text(c(1), c(2)-1, 'C')
plot(d(1), d(2), 'b*')
text(d(1), d(2)-1, 'D')