clc
clear all
close all
m=1;
sig=2;
n=1000;

M=5000;
for i=1:M
x=normrnd(m,sig,1,n); 
%oder: x=exprnd(m,sig,1,n); => fuehrt fur grosses n zum aehnlichen Ergebnis
Z(i)=sqrt(n)* (mean(x)-m)/std(x);
end

figure
hold on
ncl=25; %Anzahl Klassen im Histogramm
hist(Z,ncl) %Histogramm der absoluten Hfg.
title(['Absolute Hfg. Histogramm, ','E(X):',num2str(mean(Z)),', V(X):',num2str(var(Z,1))])
[nh,yh]=hist(Z,ncl);
figure
subplot(2,1,1);
hold on
bar(yh,nh/n,'histc') % Histogramm der relativen Hfg.
title(['Relative Hfg. Histogramm, '])
lyh=length(yh);
mid=zeros(1,lyh);
for i=1:lyh-1
mid(i)=(yh(i)+yh(i+1))/2; % Mitte der KLasse
end
mid(lyh)=yh(end);
plot(mid,nh/n,'g*')
subplot(2,1,2);
x=min(Z):0.01:max(Z);
plot(x,tpdf(x,n-1),'g*') % theoretische Dichtefkt.
title(['Theoretische Dichtefkt., StudentVerteilung'])
figure
hold on
v=sort(Z);
tt=min(Z):0.01:max(Z);
j=0;
Frep=zeros(1,length(tt));
for t=min(Z):0.01:max(Z)
j=j+1;
Frep(j)=sum(v<=t)/length(Z); % Wert in t der empirischen Verteilungsfkt.
end
plot(tt,Frep,'r.')
plot(x,tcdf(x,n-1),'b.') % theoretische Verteilungsfkt.
title(['Theoretische Verteilungsf., StudentVerteilung'])
legend('Empirische Verteilungsfkt.','Theoretische Verteilungsfkt.','Location','southeast')