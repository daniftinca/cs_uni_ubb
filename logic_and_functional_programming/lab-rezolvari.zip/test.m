disp("hello world");
perms([1,2,3])
