function result = isdreieck(a,b,c)
  if(a+b>c && b+c>a && a+c>b)
    result = 1;
  else
    result = 0;
   endif
  return
endfunction

function result = isrechtwinklig(a,b,c)
   a1 = a^2 + b^2 - c^2;
   a2 = a^2 + c^2 - b^2;
   a3 = b^2 + c^2 - a^2;
   result = a1*a2*a3;
   return
endfunction


n=1000
dreieck=0;
spitz=0;
for i=1:n
  r1=rand(1);
  r2=rand(1);
  x1=min(r1,r2);
  x2=max(r1,r2);
  a=x1;
  b=x2-x1;
  c=1-x2;
  if(isdreieck(a,b,c))
    dreieck+=1;
    if(isrechtwinklig(a,b,c)>0)
      spitz+=1;
    endif
  endif
endfor

dreieck/n
spitz/n
spitz/dreieck

close all
figure
hold on
%rectangle('Position',[0,0,1,1],'Curvature',[0,0],'Facecolor',[0,0,0])
n=1000
for i=1:n
  r1=rand(1);
  r2=rand(1);
  x1=min(r1,r2);
  x2=max(r1,r2);
  a=x1;
  b=x2-x1;
  c=1-x2;
  if(isdreieck(a,b,c) == 1 && isrechtwinklig(a,b,c) > 0)
    plot(r1,r2,'r*');
  endif
  if(isdreieck(a,b,c) == 1 && isrechtwinklig(a,b,c) <= 0)
    plot(r1,r2,'b*');
  endif
endfor
  