function [Z] = gamma2(n,beta)
  for i=1:n
    Z += -beta*log(rand());
  endfor
endfunction
 