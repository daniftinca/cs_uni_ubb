clear all
close all
figure
hold on
x = poissrnd(2,1,500);
xx = min(x):0.01:max(x);
plot(xx, poisscdf(xx, 2), 'r.');

v=sort(x);
tt=min(x):0.01:max(x);
j=0;
Frep=zeros(1,length(tt));
for t=min(x):0.01:max(x)
j=j+1;
Frep(j)=sum(v<=t)/length(x); % Wert in t der empirischen Verteilungsfkt.
end
plot(tt,Frep,'b.')

%i = 1:0.01:10;
%plot(i, i.*i, 'g.');

title('Empirische vs. theoretische Verteilung');

u = unique(x);
figure
hold on
hist(x,u);
title('Histogramm der absoluten Haufigkeit');

