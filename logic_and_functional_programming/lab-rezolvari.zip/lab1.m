ct1=0;
ct2=0;
ct3=0;
n=10000
for i=1:n 
    wurfel = randi(6,4,1);
    if(sum(wurfel == 6) > 0)
      ct1 += 1;
    endif
 endfor
pA = ct1 / n

for i=1:n
  wurfels = randi(6,24,2);
  v = (wurfels == [6,6]);
  if(sum(v(1:24,1) & v(1:24,2)) > 0)
    ct2 += 1;
  endif
endfor
pB = ct2/n

for i=1:n
  wurfels = randi(6,25,2);
  v = (wurfels == [6,6]);
  if(sum(v(1:25,1) & v(1:25,2)) > 0)
    ct3 += 1;
  endif
endfor
pB2 = ct3/n

disp("------------------------------------");

m=1000

for i=1:m 
  wurfels = randi(6,3,1);
  a(i) = sum(wurfels);
endfor
tabulate(a)
v = tabulate(a);
max_freq = max(v(:,3))
disp("Best bet: ");
for i=1:length(v)
  if (v(i,3) == max_freq)
    i
  endif
endfor

min_freq = min(v(3:length(v),3))
disp("Worst bet: ");
for i=1:length(v)
  if (v(i,3) == min_freq)
    i
  endif
endfor
  
  
  