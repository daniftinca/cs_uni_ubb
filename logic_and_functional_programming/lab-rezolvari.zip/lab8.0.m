
% Programm
clc
clear all
close all
lam=5;
N=10000;
beta=5;
n=10;
[Z]=gamma2(n,beta);
  

figure
hold on
n=25; %Anzahl Klassen im Histogramm
hist(Z,n) %Histogramm der absoluten Hfg.
title(['Absolute Hfg. Histogramm, ','E(X):',num2str(mean(Z)),', V(X):',num2str(var(Z,1))])
[nh,yh]=hist(Z,n);
figure
subplot(2,1,1);
hold on
bar(yh,nh/N,'histc') % Histogramm der relativen Hfg.
title(['Relative Hfg. Histogramm, ', 'Lambda=', num2str(lam)])
lyh=length(yh);
mid=zeros(1,lyh);
for i=1:lyh-1
mid(i)=(yh(i)+yh(i+1))/2; % Mitte der KLasse
end
mid(lyh)=yh(end);
plot(mid,nh/N,'g*')
subplot(2,1,2);
x=min(Z):0.01:max(Z);
plot(x,exppdf(x,1/lam),'g*') % theoretische Dichtefkt.
title(['Theoretische Dichtefkt., ', 'Lambda=', num2str(lam)])
figure
hold on
v=sort(Z);
tt=min(Z):0.01:max(Z);
j=0;
Frep=zeros(1,length(tt));
for t=min(Z):0.01:max(Z)
j=j+1;
Frep(j)=sum(v<=t)/length(Z); % Wert in t der empirischen Verteilungsfkt.
end
plot(tt,Frep,'r.')
plot(x,expcdf(x,1/lam),'b.') % theoretische Verteilungsfkt.
legend('Empirische Verteilungsfkt.','Theoretische Verteilungsfkt.','Location','southeast')
title(['Verteilungsfunktion, ', 'Lambda=', num2str(lam)])
