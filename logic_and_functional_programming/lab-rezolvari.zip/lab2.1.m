rectangle('Position',[0,0,1,1],'Curvature',[0,0],'EdgeColor',[0,0,1])
hold on
for i=0:0.1:2*pi
  plot(cos(i)/2 + 0.5, sin(i)/2 + 0.5,'g*')
endfor
ct = 0;
n = 100
for i=1:n
  x=[rand(),rand()];
  plot(x(1),x(2),'r*')
  if((x(1)-0.5)^2 + (x(2)-0.5)^2 <= 0.25)
    ct++;
  endif
endfor
disp("WKt:");
ct/n