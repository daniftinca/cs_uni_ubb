function result = sign(p1, p2, p3)
  result = (p1(1) - p3(1))*(p2(2)-p3(2)) - (p2(1) - p3(1)) * (p1(2) - p3(2));
  return;
endfunction

function result = pointInTriangle(pt, v1, v2, v3)
  b1 = sign(pt, v1, v2) < 0.0;
  b2 = sign(pt, v2, v3) < 0.0;
  b3 = sign(pt, v3, v1) < 0.0;
  
  result = ((b1 == b2) && (b2 == b3));
  return;
endfunction;

close all
figure 
hold on 
 v1 = [randi(10), randi(10)]
 v2 = [randi(10), randi(10)]
 v3 = [randi(10), randi(10)]
 pt = [randi(10), randi(10)]
 
 plot(v1(1), v1(2), 'b*')
 plot(v2(1), v2(2), 'b*')
 plot(v3(1), v3(2), 'b*')
 plot(pt(1), pt(2), 'r*')
 
 pointInTriangle(pt, v1, v2, v3)