clc
clear all
figure
rectangle('Position', [0,0,10,10],'LineWidth',3)
grid on
hold on
%line([0 1],[1 1],'LineWidth',3,'Color','red','LineStyle','--')
%pause(0.3)
%plot([1 1],[1 2],'LineWidth',3,'Color','red','LineStyle','--')
%pause(0.3)
%plot([1 2],[2 2],'LineWidth',3,'Color','red','LineStyle','--')

x=0
y=10
p = 0.5
while (x < 10 || y > 0)
  wkt = floor(rand() + p);
  if (wkt == 1 && x+1 <= 10)
    plot([x x+1],[y y],'LineWidth',3,'Color','blue','LineStyle','--')
    x = x+1;
  endif
  if (wkt == 0 && y-1 >= 0)
    plot([x x],[y y-1],'LineWidth',3,'Color','blue','LineStyle','--')
    y = y-1;
  endif
  pause(0.3)
endwhile