function res = shuffle(X)
n = length(X);
for i = 2:n % forward
w = ceil(rand*i); % 1 <= w <= i % a random number = floor(rand*i)+1
t = X(w);
X(w) = X(i);
X(i) = t;
end
res = X;
return
endfunction
%%%%


X=['a','b','c','d','1','2','3'] ;

n = 100
wkt_2j = 0;
wkt_2m = 0;
wkt_ej = 0;
wkt_em = 0;
for i=1:n
  X = shuffle(X);
  X;
  for i=2:length(X)
    if(X(i) >= 'a' && X(i) <= 'd' && X(i-1) >= 'a' && X(i-1) <= 'd')
      wkt_2j += 1;
     endif
    if(X(i) >= '1' && X(i) <= '3' && X(i-1) >= '1' && X(i-1) <= '3')
      wkt_2m += 1;
    endif
  endfor
  if(X(1) >= 'a' && X(1) <= 'd' && 
  X(length(X)) >= 'a' && X(length(X)) <= 'd')
    wkt_ej++;
  endif
  if(X(1) >= '1' && X(1) <= '3' && 
  X(length(X)) >= '1' && X(length(X)) <= '3')
    wkt_em += 1;
  endif
endfor

wkt_2j/n
wkt_2m/n
wkt_ej/n
wkt_em/n