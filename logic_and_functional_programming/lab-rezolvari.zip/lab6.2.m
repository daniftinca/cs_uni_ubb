function result = bell(n, k)
  if(n == 1)
    result = 1;
    return
  endif
  if(n == 2)
    if(k == 1)
      result = 1;
    else
      result = 2;
    endif
  return
  endif
  if(k == 1)
    result = bell(n-1,n-1);
    return
  else
    result = bell(n-1,k-1) + bell(n, k-1);
    return
  endif
endfunction

bell(5,3)

n = 8
for i=1:n
  for j=1:i
    printf("%d \t", bell(i,j));
  endfor
  printf("\n");
endfor