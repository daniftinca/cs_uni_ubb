n=1000
ct=0;
for i=1:n
  s1 = randi(6) + randi(6);
  s2 = randi(6) + randi(6);
  while(s1!=6 && s2!=7)
    s1 = randi(6) + randi(6);
    s2 = randi(6) + randi(6);
  endwhile
  if(s1==6)
    ct+=1;
  endif
endfor

ct/n