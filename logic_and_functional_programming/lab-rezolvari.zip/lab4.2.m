function a=approx(k)
  if k==1
    a=3;
  else
    s=3*2^(k-1);
    a=s*sqrt(2-2*sqrt(1-(approx(k-1)/s)^2));
  end
end

function a=fibonacci(n)
   if(n<=1)
      a=n;
      return;
   else
      a=fibonacci(n-1) + fibonacci(n-2);
      return;
   end
end