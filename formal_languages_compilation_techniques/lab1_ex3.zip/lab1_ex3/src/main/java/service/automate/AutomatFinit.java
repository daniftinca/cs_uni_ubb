package service.automate;

import java.util.*;
import java.util.stream.Collectors;

public class AutomatFinit {
    private List<State> states;
    private List<Transition> transitions;

    public AutomatFinit(List<State> states, List<Transition> transitions) {
        this.states = states;
        this.transitions = transitions;
    }

    public AutomatFinit() {
        this.states = new ArrayList<>();
        this.transitions = new ArrayList<>();
    }

    /**
     * Returns a list of all the characters in the alphabet.
     *
     * @return
     */
    public List<String> getAlphabet() {
        return this.transitions.stream()
                .map(Transition::getValue)
                .distinct()
                .collect(Collectors.toList());
    }


    /**
     * Returns a list of all the final states.
     *
     * @return
     */
    public List<State> getFinalStates() {
        return this.states.stream()
                .filter(State::getFinal)
                .collect(Collectors.toList());
    }

    private State getInitial() {
        for (State state : this.states) {
            if (state.getInitial()) {
                return state;
            }
        }
        return null;
    }

    private List<Transition> getTransitionsFromState(State s) {
        return this.transitions.stream()
                .filter(transition -> transition.getFrom().equals(s.getName()))
                .collect(Collectors.toList());
    }

    private State getStateByName(String name) {
        for (State state : this.states) {
            if (state.getName().equals(name)) {
                return state;
            }
        }
        return null;
    }

    /**
     * Tests if a sequence is accepted by the automate and logs the steps as well.
     *
     * @param sequence
     * @return
     * @throws Exception
     */
    public Boolean accepts(String sequence) throws Exception {
        List<String> values = Arrays.asList(sequence.split(""));
        State currentState = getInitial();
        if (currentState == null) {
            throw new Exception("invalid automat");
        }

        if(currentState.getFinal()&&sequence.equals("")){
            return true;
        }

        for (String value : values) {
            List<Transition> transitions = getTransitionsFromState(currentState);
            boolean foundSomething = false;
            for (Transition transition : transitions) {

                if (value.equals(transition.getValue())) {
                    System.out.println("From: " + currentState.getName() + " to " + transition.getTo() + " with value: " + transition.getValue());
                    currentState = getStateByName(transition.getTo());
                    transitions = getTransitionsFromState(currentState);
                    foundSomething = true;
                    break;
                }
            }
            if (!foundSomething) {
                System.out.println("Stopped at " + currentState.getName());
                return false;
            }
        }
        if (!currentState.getFinal()) {
            return false;
        }
        return true;
    }

    /**
     * Returns the longest prefix of a sequence which is accepted.
     *
     * @param sequence
     * @return
     * @throws Exception
     */
    public String getLongestAcceptedPrefix(String sequence) throws Exception {
        String prefix = "";
        StringBuilder sb = new StringBuilder(prefix);
        List<String> values = Arrays.asList(sequence.split(""));
        State currentState = getInitial();


        Integer lastFinalAutomateValueIndex = 0;
        if (currentState == null) {
            throw new Exception("invalid automat");
        }
        Integer someDummyIndex = 0;
        for (String value : values) {
            List<Transition> transitions = getTransitionsFromState(currentState);

            boolean foundSomething = false;
            for (Transition transition : transitions) {

                if (value.equals(transition.getValue())) {
                    System.out.println("From: " + currentState.getName() + " to " + transition.getTo() + " with value: " + transition.getValue());
                    if(currentState.getFinal()){
                        lastFinalAutomateValueIndex = someDummyIndex;
                    }
                    currentState = getStateByName(transition.getTo());
                    transitions = getTransitionsFromState(currentState);

                    foundSomething = true;
                    sb.append(value);
                    break;
                }
            }
            if (!foundSomething) {
                System.out.println("Stopped at " + currentState.getName());

                return sb.toString();
            }
            someDummyIndex++;
        }
        if (!currentState.getFinal()) {
            System.out.println("Stopped at " + currentState.getName());
            System.out.println("Latest Final State: the "+lastFinalAutomateValueIndex+"th");
            sb = new StringBuilder();
            for(int i=0;i<lastFinalAutomateValueIndex;i++){
                sb.append(values.get(i));
            }
            return sb.toString();
        }
        return sb.toString();
    }

    public List<State> getStates() {
        return states;
    }

    public void setStates(List<State> states) {
        this.states = states;
    }

    public List<Transition> getTransitions() {
        return transitions;
    }

    public void setTransitions(List<Transition> transitions) {
        this.transitions = transitions;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AutomatFinit that = (AutomatFinit) o;
        return Objects.equals(states, that.states) &&
                Objects.equals(transitions, that.transitions);
    }

    @Override
    public int hashCode() {

        return Objects.hash(states, transitions);
    }

    @Override
    public String toString() {
        return "AutomatFinit{" +
                "states=" + states +
                ", transitions=" + transitions +
                '}';
    }
}
