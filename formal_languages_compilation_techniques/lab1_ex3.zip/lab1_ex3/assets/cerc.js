class Cerc {
    constructor(r) {
        this.1234raza = r;
        this.asdfw = " ";
    }

}

function cerc(raza) {
    var 23413;
    pi = 3.14;
    return [2 * raza * pi, pi * raza * raza];
}